import Content from "./content"
import Layout from "./layout"

export default function Dashboard() {
  return (
    <Layout>
      <Content />
    </Layout>
  )
}
