import { Sidebar } from "@/components/sidebar"
import { DashboardHeader } from "@/components/dashboard-header"
import { MetricsGrid } from "@/components/metrics-grid"
import { ChartsSection } from "@/components/charts-section"
import { BillingOverview } from "@/components/billing-overview"
import { UserActivity } from "@/components/user-activity"

export default function DashboardPage() {
  return (
    <div className="flex min-h-screen bg-slate-50">
      <Sidebar />
      <main className="flex-1 lg:ml-64">
        <DashboardHeader />
        <div className="p-6 space-y-6">
          <div className="mb-8">
            <h1 className="font-heading text-3xl font-black text-slate-900 mb-2">Visão Geral de Performance</h1>
            <p className="text-slate-600 font-sans">Acompanhe suas métricas principais e insights em tempo real</p>
          </div>

          <MetricsGrid />
          <ChartsSection />

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <BillingOverview />
            <UserActivity />
          </div>
        </div>
      </main>
    </div>
  )
}
