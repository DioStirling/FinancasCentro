import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { TrendingUp, TrendingDown, Users, DollarSign, Activity } from "lucide-react"

const metrics = [
  {
    title: "Receita Total",
    value: "R$ 45.231",
    change: "+20.1%",
    trend: "up",
    icon: DollarSign,
  },
  {
    title: "Usuários Ativos",
    value: "2.350",
    change: "+180.1%",
    trend: "up",
    icon: Users,
  },
  {
    title: "Taxa de Conversão",
    value: "12.5%",
    change: "-2.5%",
    trend: "down",
    icon: Activity,
  },
  {
    title: "Crescimento MRR",
    value: "R$ 12.234",
    change: "+19%",
    trend: "up",
    icon: TrendingUp,
  },
]

export function MetricsGrid() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {metrics.map((metric) => (
        <Card key={metric.title} className="border-0 shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-slate-600">{metric.title}</CardTitle>
            <metric.icon className="h-4 w-4 text-slate-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-heading font-bold text-slate-900">{metric.value}</div>
            <div className="flex items-center space-x-1 text-xs">
              {metric.trend === "up" ? (
                <TrendingUp className="h-3 w-3 text-green-500" />
              ) : (
                <TrendingDown className="h-3 w-3 text-red-500" />
              )}
              <span className={metric.trend === "up" ? "text-green-600" : "text-red-600"}>{metric.change}</span>
              <span className="text-slate-500">vs mês anterior</span>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
