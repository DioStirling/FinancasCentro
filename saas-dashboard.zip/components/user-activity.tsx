import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Activity } from "lucide-react"

const activities = [
  {
    user: "Maria Santos",
    action: "Criou novo projeto",
    time: "2 min atrás",
    avatar: "MS",
  },
  {
    user: "João Silva",
    action: "Atualizou configurações",
    time: "5 min atrás",
    avatar: "JS",
  },
  {
    user: "Ana Costa",
    action: "Fez upload de arquivo",
    time: "10 min atrás",
    avatar: "AC",
  },
  {
    user: "Pedro Lima",
    action: "Convidou novo membro",
    time: "15 min atrás",
    avatar: "PL",
  },
  {
    user: "Carla Mendes",
    action: "Exportou relatório",
    time: "20 min atrás",
    avatar: "CM",
  },
]

export function UserActivity() {
  return (
    <Card className="border-0 shadow-sm">
      <CardHeader>
        <CardTitle className="font-heading text-lg font-bold text-slate-900 flex items-center">
          <Activity className="w-5 h-5 mr-2" />
          Atividade dos Usuários
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {activities.map((activity, index) => (
            <div key={index} className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-cyan-100 rounded-full flex items-center justify-center">
                <span className="text-xs font-medium text-cyan-700">{activity.avatar}</span>
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-slate-900">{activity.user}</p>
                <p className="text-sm text-slate-500">{activity.action}</p>
              </div>
              <div className="text-xs text-slate-400">{activity.time}</div>
            </div>
          ))}
        </div>

        <div className="mt-6 pt-4 border-t border-slate-200">
          <button className="text-sm text-blue-600 hover:text-blue-700 font-medium">Explorar Mais Insights →</button>
        </div>
      </CardContent>
    </Card>
  )
}
